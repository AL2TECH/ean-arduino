/*
 * 	EAN_LED.h
 *	Description: led module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_LED_H_
#define  _EAN_LED_H_

class EAN_LED
{
  public:

    EAN_LED(void);
    void leds_on(void);
    void leds_off(void);

    void add_console_tests(void);

  private:

};

extern EAN_LED LED;

#endif


