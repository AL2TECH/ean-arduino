/*
 * 	EAN_Scheduler.h
 *	Description: Power Manager module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_SCHEDULER_H_
#define  _EAN_SCHEDULER_H_

#include <stdint.h>
#include <Preferences.h>

#define SCHEDULER_NUMBER_TASKS 4

// forward declaration  task struct
struct scheduler_task;

/**
 * task callback function
 *
 * @param task pointer
 */
typedef void (*task_callback)(struct scheduler_task*);

/**
 * Task structure
 */
typedef struct scheduler_task {
	uint8_t task_id;
	bool task_enabled;
  uint32_t next_run_time;
  uint32_t interval_time;
  task_callback callback;
} scheduler_task_t;

class EAN_Scheduler
{
  public:


    EAN_Scheduler(void);
    void set_task_enable(uint8_t task_id, bool enable);
    bool get_task_enable(uint8_t task_id);
    void set_task_next_run_time(uint8_t task_id, uint32_t next_run_time);
    uint32_t get_task_next_run_time(uint8_t task_id);
    void set_task_interval_time(uint8_t task_id, uint32_t interval_time);
    uint32_t get_task_interval_time(uint8_t task_id);
    void assign_task_callback(uint8_t task_id, task_callback callback);
    uint32_t run(void);
    uint32_t get_next_run_time(void);
    void load_tasks(void);
    void store_tasks(void);
    void clear_tasks(void);
    void print_tasks(void);

    void add_console_tests(void);

  private:

    scheduler_task_t _scheduler_task[SCHEDULER_NUMBER_TASKS];
    Preferences _preferences;


};

extern EAN_Scheduler Scheduler;

#endif


