/*
 * 	EAN_Scheduler.c
 *	Description: Scheduler module
 *  Created on: 02 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#include "EAN_Scheduler.h"
#include "EAN_Console.h"
#include "EAN_System_Time.h"
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

#define SCH_FORCE_RUN_DEL 1
#define SCHEDULER_PREF_NAME "scheduler_"

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
EAN_Scheduler::EAN_Scheduler(void){

    // disbale all tasks
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++){

		_scheduler_task[i].task_enabled = false;
		_scheduler_task[i].task_id = i;
		_scheduler_task[i].callback = NULL;
	}

}

void EAN_Scheduler::set_task_enable(uint8_t task_id, bool enable) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    _scheduler_task[task_id].task_enabled = enable;
	}

}

bool EAN_Scheduler::get_task_enable(uint8_t task_id) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    return _scheduler_task[task_id].task_enabled;
	}else{
        return false;
    }

}

void EAN_Scheduler::set_task_next_run_time(uint8_t task_id, uint32_t next_run_time) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    _scheduler_task[task_id].next_run_time = next_run_time;
	}

}

uint32_t EAN_Scheduler::get_task_next_run_time(uint8_t task_id) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    return _scheduler_task[task_id].next_run_time;
	}else{
        return 0;
    }

}

void EAN_Scheduler::set_task_interval_time(uint8_t task_id, uint32_t interval_time) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    _scheduler_task[task_id].interval_time = interval_time;
	}

}

uint32_t EAN_Scheduler::get_task_interval_time(uint8_t task_id) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    return _scheduler_task[task_id].interval_time;
	}else{
        return 0;
    }

}

void EAN_Scheduler::assign_task_callback(uint8_t task_id, task_callback callback) {

    if(task_id < SCHEDULER_NUMBER_TASKS){
	    _scheduler_task[task_id].callback = callback;
	}

}

uint32_t EAN_Scheduler::run(void) {

    uint32_t current_time, next_run_time;

	//get current time
	current_time = System_Time.get_time_epoch_format();
	Serial.print("SCHEDULER: RUN AT ");
    Serial.println(current_time);

	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS ; i++){
		//if task timer expired run the callback and set the new run time
		if((_scheduler_task[i].next_run_time <= current_time) && (_scheduler_task[i].task_enabled) ){
            Serial.print("SCHEDULER: RUN TASK ID ");
            Serial.println(_scheduler_task[i].task_id);
			_scheduler_task[i].callback(&_scheduler_task[i]);
			_scheduler_task[i].next_run_time = _scheduler_task[i].next_run_time + _scheduler_task[i].interval_time;
		}
	}

    next_run_time = get_next_run_time();
    current_time = System_Time.get_time_epoch_format();

    return (next_run_time-current_time);
}

uint32_t EAN_Scheduler::get_next_run_time(void) {

    uint32_t current_time;
    uint32_t next_run_time = 0xFFFFFFFF;

	//get current time
	current_time = System_Time.get_time_epoch_format();

	// serach for the minimum next_run_time
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS ; i++){
		if((_scheduler_task[i].next_run_time < next_run_time) && (_scheduler_task[i].task_enabled)){
			next_run_time = _scheduler_task[i].next_run_time;
		}
	}

	// force immediate execution if the scheduler has some expired tasks
	if(current_time >= next_run_time){
		next_run_time = current_time + SCH_FORCE_RUN_DEL;
	}

	Serial.print("SCHEDULER: NEXT RUN AT ");
    Serial.println(next_run_time);

    return next_run_time;

}

void EAN_Scheduler::store_tasks(void) {

	String pref_name;
    
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++){

		pref_name = SCHEDULER_PREF_NAME + String(i);
		_preferences.begin(pref_name.c_str(), false);

		_preferences.putUChar("task_id", _scheduler_task[i].task_id);
		_preferences.putBool("task_enabled", _scheduler_task[i].task_enabled);
		_preferences.putULong("next_run_time", _scheduler_task[i].next_run_time);
		_preferences.putULong("interval_time", _scheduler_task[i].interval_time);
		_preferences.putULong("callback", (uint32_t)_scheduler_task[i].callback);

		_preferences.end();
	}
}

void EAN_Scheduler::load_tasks(void) {

	String pref_name;
    
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++){


		pref_name = SCHEDULER_PREF_NAME + String(i);
		_preferences.begin(pref_name.c_str(), true);

		_scheduler_task[i].task_id = _preferences.getUChar("task_id", 0);
		_scheduler_task[i].task_enabled = _preferences.getBool("task_enabled", false);
		_scheduler_task[i].next_run_time = _preferences.getULong("next_run_time", 0);
		_scheduler_task[i].interval_time = _preferences.getULong("interval_time", 0);
		_scheduler_task[i].callback = (task_callback) _preferences.getULong("callback", 0);

		_preferences.end();
	}
}

void EAN_Scheduler::clear_tasks(void) {

	String pref_name;
    
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++){

		pref_name = SCHEDULER_PREF_NAME + String(i);
		_preferences.begin(pref_name.c_str(), false);

		_preferences.putUChar("task_id", _scheduler_task[i].task_id);
		_preferences.putBool("task_enabled", false);
		_preferences.putULong("next_run_time", 0);
		_preferences.putULong("interval_time", 0);
		_preferences.putULong("callback", 0);

		_preferences.end();
	}
}

void EAN_Scheduler::print_tasks(void) {

    
	for(uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++){

		Serial.printf("TASK ID: %u\r\n", _scheduler_task[i].task_id);
		Serial.printf("TASK ENABLED: %u\r\n", _scheduler_task[i].task_enabled);
		Serial.printf("TASK NEXT RUN TIME: %lu\r\n", _scheduler_task[i].next_run_time);
		Serial.printf("TASK INTERVAL TIME: %lu sec\r\n", _scheduler_task[i].interval_time);
		Serial.printf("TASK CALLBACK ADDR: 0x%08lx\r\n", (uint32_t) _scheduler_task[i].callback);
		Serial.println("");
	}
}

void EAN_Scheduler::add_console_tests(void) {
    
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/


// Instance of the EAN_Scheduler;
EAN_Scheduler Scheduler;