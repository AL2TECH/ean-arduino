### EAN_Console
  EAN Console framework
  
### EAN_LED
  EAN LED manager library
  
### EAN_LSM6DSOX
  Deived from Arduino_LSM6DSOX Library.
  
### EAN_System_Time
  EAN System Time library

### EAN_Power_Manager
  EAN Power Manager library
  
### EAN_Scheduler
  EAN Scheduler library
  
### Wire
  Arduino compatible I2C driver

### Preferences
  Flash keystore using ESP32 NVS