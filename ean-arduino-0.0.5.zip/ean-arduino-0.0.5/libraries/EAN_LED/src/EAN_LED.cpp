/*
 * 	EAN_LED.c
 *	Description: led module
 *  Created on: 02 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#include "EAN_LED.h"
#include <EAN_Console.h>
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

#if LEDS_NUMBER > 0
static const uint8_t m_board_leds_list[LEDS_NUMBER] = LEDS_LIST;
#endif

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _leds_on_test_func(const String argument);
static void _leds_off_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
EAN_LED::EAN_LED(void){

    for (uint8_t i = 0; i < LEDS_NUMBER; i++){
        pinMode(m_board_leds_list[i], OUTPUT);
        digitalWrite(m_board_leds_list[i], HIGH);
    }

}


void EAN_LED::leds_on(void) {
    for (uint8_t i = 0; i < LEDS_NUMBER; i++){
        digitalWrite(m_board_leds_list[i], LOW);
    }
}

void EAN_LED::leds_off(void) {
    for (uint8_t i = 0; i < LEDS_NUMBER; i++){
        digitalWrite(m_board_leds_list[i], HIGH);
    }
}

void EAN_LED::add_console_tests(void) {
    
    test_config_t leds_on_test = {.menu_string = "leds_on",
                          .cmd_string  = "leds_on",
                          .p_test      =  _leds_on_test_func };


    Console.add_console_test(&leds_on_test);

    test_config_t leds_off_test = {.menu_string = "leds_off",
                          .cmd_string  = "leds_off",
                          .p_test      = _leds_off_test_func};


    Console.add_console_test(&leds_off_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

static void  _leds_on_test_func(const String argument){
      LED.leds_on();
}

static void  _leds_off_test_func(const String argument){
      LED.leds_off();
}

// Instance of the EAN_LED;
EAN_LED LED;