/*
 * 	AL2TECH_LED.c
 *	Description: led module
 *  Created on: 02 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#include "AL2TECH_LED.h"
#include <AL2TECH_Console.h>
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/


/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _turn_on_test_func(const String argument);
static void _turn_off_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
AL2TECH_LED::AL2TECH_LED(void){
    pinMode(2, OUTPUT); 
    pinMode(8, OUTPUT); 
    pinMode(10, OUTPUT);
    digitalWrite(2, HIGH); 
    digitalWrite(8, HIGH); 
    digitalWrite(10, HIGH); 
}


void AL2TECH_LED::turn_on(void) {
    digitalWrite(2, LOW);
}

void AL2TECH_LED::turn_off(void) {
    digitalWrite(2, HIGH);
}

void AL2TECH_LED::add_console_tests(void) {
    
    test_config_t turn_on_test = {.menu_string = "led_on",
                          .cmd_string  = "led_on",
                          .p_test      =  _turn_on_test_func };


    AL2_Console.add_console_test(&turn_on_test);

    test_config_t turn_off_test = {.menu_string = "led_off",
                          .cmd_string  = "led_off",
                          .p_test      = _turn_off_test_func};


    AL2_Console.add_console_test(&turn_off_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

static void  _turn_on_test_func(const String argument){
      AL2_LED.turn_on();
}

static void  _turn_off_test_func(const String argument){
      AL2_LED.turn_off();
}

// Instance of the AL2TECH_LED;
AL2TECH_LED AL2_LED;