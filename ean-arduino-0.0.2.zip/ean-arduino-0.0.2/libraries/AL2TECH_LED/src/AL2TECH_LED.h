/*
 * 	AL2TECH_LED.h
 *	Description: led module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

class AL2TECH_LED
{
  public:

    AL2TECH_LED(void);
    void turn_on(void);
    void turn_off(void);

    void add_console_tests(void);

  private:

};

extern AL2TECH_LED AL2_LED;


