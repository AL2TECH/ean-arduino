/*
 * 	EAN_Power_Manager.h
 *	Description: Power Manager module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_POWER_MANAGER_H_
#define  _EAN_POWER_MANAGER_H_

#include <stdint.h>

typedef enum {
  WAKEUP_STATE_RESET,    
  WAKEUP_STATE_DEEP_SLEEP, 
} wakeup_state_t;

class EAN_Power_Manager
{
  public:


    EAN_Power_Manager(void);
    void enter_deep_sleep(uint32_t wake_up_delay_sec);
    void enter_deep_sleep_until(uint32_t wake_up_time_epoch);
    void enter_light_sleep(uint32_t wake_up_delay_sec);
    void enter_light_sleep_until(uint32_t wake_up_time_epoch);
    void set_cpu_freq(uint32_t cpu_freq_MHz);
    wakeup_state_t get_wakeup_state(void);

    void add_console_tests(void);

  private:

};

extern EAN_Power_Manager Power_Manager;

#endif


