/*
 * 	EAN_Power_Manager.c
 *	Description: System time module
 *  Created on: 02 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#include "EAN_Power_Manager.h"
#include "EAN_Console.h"
#include "EAN_System_Time.h"
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

#define uS_TO_S_FACTOR 1000000ULL  /* Conversion factor for micro seconds to seconds */

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _enter_light_test_func(const String argument);
static void _enter_deep_test_func(const String argument);
static void _get_wakeup_test_func(const String argument);
static void _get_cpu_freq_test_func(const String argument);
static void _set_cpu_freq_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
EAN_Power_Manager::EAN_Power_Manager(void){

}


void EAN_Power_Manager::enter_deep_sleep(uint32_t wake_up_delay_sec) {

    esp_sleep_enable_timer_wakeup(wake_up_delay_sec * uS_TO_S_FACTOR);
    esp_deep_sleep_start();

}

void EAN_Power_Manager::enter_deep_sleep_until(uint32_t wake_up_time_epoch) {

    uint32_t curr_time;
    curr_time = System_Time.get_time_epoch_format();

	// negative wait time error managment
	if (wake_up_time_epoch < curr_time) {
		wake_up_time_epoch = curr_time;
	}

    enter_deep_sleep((wake_up_time_epoch - curr_time));

}

void EAN_Power_Manager::enter_light_sleep(uint32_t wake_up_delay_sec) {

    esp_sleep_enable_timer_wakeup(wake_up_delay_sec * uS_TO_S_FACTOR);
    esp_light_sleep_start();

}

void EAN_Power_Manager::enter_light_sleep_until(uint32_t wake_up_time_epoch) {

    uint32_t curr_time;
    curr_time = System_Time.get_time_epoch_format();

	// negative wait time error managment
	if (wake_up_time_epoch < curr_time) {
		wake_up_time_epoch = curr_time;
	}

    enter_light_sleep((wake_up_time_epoch - curr_time));

}

wakeup_state_t EAN_Power_Manager::get_wakeup_state(void) {

    esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();

    if(wakeup_reason == ESP_SLEEP_WAKEUP_TIMER){
        return WAKEUP_STATE_DEEP_SLEEP;
    }else{
        return WAKEUP_STATE_RESET;
    }

}

void EAN_Power_Manager::set_cpu_freq(uint32_t cpu_freq_MHz) {

    setCpuFrequencyMhz(cpu_freq_MHz);

}

void EAN_Power_Manager::add_console_tests(void) {
    
    test_config_t enter_light_test = {.menu_string = "enter_light <sec>",
                          .cmd_string  = "enter_light",
                          .p_test      =  _enter_light_test_func };


    Console.add_console_test(&enter_light_test);

    test_config_t enter_deep_test = {.menu_string = "enter_deep <sec>",
                          .cmd_string  = "enter_deep",
                          .p_test      =  _enter_deep_test_func };


    Console.add_console_test(&enter_deep_test);

    test_config_t get_wakeup_test = {.menu_string = "get_wakeup",
                          .cmd_string  = "get_wakeup",
                          .p_test      =  _get_wakeup_test_func };


    Console.add_console_test(&get_wakeup_test);

    test_config_t get_cpu_freq_test = {.menu_string = "get_cpu_freq",
                          .cmd_string  = "get_cpu_freq",
                          .p_test      =  _get_cpu_freq_test_func };


    Console.add_console_test(&get_cpu_freq_test);

    test_config_t set_cpu_freq_test = {.menu_string = "set_cpu_freq <freq_MHz>",
                          .cmd_string  = "set_cpu_freq",
                          .p_test      =  _set_cpu_freq_test_func };


    Console.add_console_test(&set_cpu_freq_test);

}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

static void  _enter_light_test_func(const String argument){
    uint32_t sleep_time_sec = (uint32_t) strtol(argument.c_str(), NULL, 10);
    Serial.println("ENTERING LIGHT SLEEP");
    Power_Manager.enter_light_sleep(sleep_time_sec);
    esp_restart();

}

static void  _enter_deep_test_func(const String argument){
    uint32_t sleep_time_sec = (uint32_t) strtol(argument.c_str(), NULL, 10);
    Serial.println("ENTERING DEEP SLEEP");
    Power_Manager.enter_deep_sleep(sleep_time_sec);

}

static void  _get_wakeup_test_func(const String argument){

    wakeup_state_t wu_state = Power_Manager.get_wakeup_state();
    Serial.print("WAKE UP FROM: ");
    if(wu_state == WAKEUP_STATE_DEEP_SLEEP){
        Serial.println("DEEP SLEEP");
    }else{
        Serial.println("RESET");
    }
}

static void  _get_cpu_freq_test_func(const String argument){

    uint32_t cpu_freq_MHz = getCpuFrequencyMhz();
    wakeup_state_t wu_state = Power_Manager.get_wakeup_state();
    Serial.println("CPU FREQ: " + String(cpu_freq_MHz) + " MHz");

}

static void  _set_cpu_freq_test_func(const String argument){

    uint32_t cpu_freq_MHz =  (uint32_t) strtol(argument.c_str(), NULL, 10);
    Power_Manager.set_cpu_freq(cpu_freq_MHz);

}


// Instance of the EAN_Power_Manager;
EAN_Power_Manager Power_Manager;