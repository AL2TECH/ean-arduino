/*
 * 	EAN_Scheduler.h
 *	Description: Power Manager module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_SCHEDULER_H_
#define  _EAN_SCHEDULER_H_

#include <stdint.h>

#include "EAN_Task.h"

#define SCHEDULER_NUMBER_TASKS 4

class EAN_Scheduler
{
public:
  EAN_Scheduler(void);

  uint32_t run(void);
  uint32_t getNextRunTime(void);

  void addTask(EAN_Task *p_task);
  void removeTask(const uint8_t task_id);

  EAN_Task getTask(const uint8_t task_sel_id);

  void printTasks(void);
  void removeAllTasks(void);

private:
  EAN_Task _tasks[SCHEDULER_NUMBER_TASKS];
};

extern EAN_Scheduler Scheduler;

#endif
