/*
 * 	AL2TECH_Console.c
 *	Description: console module
 *  Created on: 02 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#include "AL2TECH_Console.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

#define SERIAL_TIMEOUT_MS 20000

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/


/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _get_version_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
AL2TECH_Console::AL2TECH_Console(void){
    _console_test_head = 0;
    _console_input.command="";
    _console_input.argument="";

    _add_console_tests();
}

/**	@brief		add a single CONSOLE test
 * 				helper function to be used to load CONSOLE test in the framework
 * 	@param[in] 	test_configuration pointer to the test_config_t to be instantiated in the framework
 * 	@return 	true on success, false the CONSOLE test buffer is full
 */
bool AL2TECH_Console::add_console_test(const test_config_t *test_configuration) {
    // check if the console_test buffer has at least one space left
    if (_console_test_head >= CONSOLE_MAX_NUM_TEST) { return false; }

    // configure the console Test and increment head
    _console_test[_console_test_head].menu_string = test_configuration->menu_string;
    _console_test[_console_test_head].cmd_string  = test_configuration->cmd_string;
    _console_test[_console_test_head].p_test      = test_configuration->p_test;
    _console_test_head++;

    return true;
}

/** @brief	Execute CONSOLE Test Framework
 * 			to be called by the user
 * 	@return	This function will never return
 */
void AL2TECH_Console::run_console(void) {

    Serial.setTimeout(SERIAL_TIMEOUT_MS);

    // print menu
    _run_console_framework_print_menu();

    // Forever Loop
    while (1) {

        // wait console input
        while (!_get_console_input()) {};

        // process console input
        _run_framework_test_execution();
    }
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/**	@brief	Get console inpout
 * @param	Void.
 * @return	true if a comamnd has been recived.
 */
bool AL2TECH_Console::_get_console_input(void) {

    String input_str;

    input_str = Serial.readStringUntil(CONSOLE_EOC);
    
    if(!input_str.length()){
        return false;
    }

    _console_input.command = input_str.substring(0, input_str.indexOf(CONSOLE_COMMAND_SEP));
    _console_input.argument = input_str.substring(input_str.indexOf(CONSOLE_COMMAND_SEP) +1);

    return true;
}

/**	@brief	Run_console_framework_print_menu
 *			prints all the menu strings associated with all tests configured
 * 			within the console framework.
 * @param	Void.
 * @return	Void.
 */
__attribute__ ((unused))
void AL2TECH_Console::_run_console_framework_print_menu(void) {

	#ifdef CONSOLE_PRINT_MENU
    Serial.println("\r#### CONSOLE FRAMEWORK MENU ####");

    for (uint8_t i = 0; i < _console_test_head; i++) {
        Serial.println(_console_test[i].menu_string);
    }

    Serial.println("\rEnter Command: ");
	#endif
}

/**	@brief 	run commanded test routine
 * 			compare the entered command with all the configured test and launches the
 * 			selected one. If the command entered doesn't match any configured test
 * 			prints an error message.
 * @param	Void.
 * @return	Void.
 */
void AL2TECH_Console::_run_framework_test_execution(void) {
    bool is_command_valid = false;

    // search for the command to be executed, if not prints error message
    for (uint8_t i = 0; i < _console_test_head; i++) {
        if (_console_test[i].cmd_string ==  _console_input.command) {
            // launch the commanded test
            is_command_valid = true;
            _console_test[i].p_test(_console_input.argument);
        }
    }

    if (!is_command_valid) {
    	Serial.println("Invalid Command\r");
    	_run_console_framework_print_menu();
    }
}

void AL2TECH_Console::_add_console_tests(void) {
    
    test_config_t get_version_test = {.menu_string = "get_version",
                            .cmd_string  = "get_version",
                            .p_test      = _get_version_test_func};


    add_console_test(&get_version_test);
}
/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
static void  _get_version_test_func(const String argument){
      Serial.print("version "); 
      Serial.println(BOARD_PACKAGE_VERSION);
}

// Instance of the AL2TECH_Console;
AL2TECH_Console AL2_Console;
