/*
 * 	AL2TECH_LED.h
 *	Description: led module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _AL2TECH_LED_H_
#define  _AL2TECH_LED_H_

#define LED_RED   2
#define LED_GREEN 8
#define LED_BLUE  10

class AL2TECH_LED
{
  public:

    AL2TECH_LED(void);
    void turn_on(void);
    void turn_off(void);

    void add_console_tests(void);

  private:

};

extern AL2TECH_LED AL2_LED;

#endif


