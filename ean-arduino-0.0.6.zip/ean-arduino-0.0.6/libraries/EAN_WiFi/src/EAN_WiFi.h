/*
 * 	EAN_WiFi.h
 *	Description: wifi module
 *  Created on: 9 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef _EAN_WiFi_H_
#define _EAN_WiFi_H_
#include <WiFi.h>
#include <stdint.h>
class EAN_WiFi
{
public:
  EAN_WiFi(void);
  bool connect(const char *ssid, const char *pwd, const unsigned long timeoutLength = 10);
  bool disconnect(bool eraseap);
  bool isConnected(void);
  wl_status_t getStatus(void);
  void add_console_tests(void);

  IPAddress getIp(void); // IPAddress: https://github.com/espressif/arduino-esp32/blob/2.0.7/cores/esp32/IPAddress.h
};

extern EAN_WiFi EWiFi;

#endif
