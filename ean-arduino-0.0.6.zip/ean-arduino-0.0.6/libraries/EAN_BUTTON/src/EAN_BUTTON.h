/*
 * 	EAN_BUTTON.h
 *	Description: button module
 *  Created on: 10 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef _EAN_BUTTON_H_
#define _EAN_BUTTON_H_

#include <stdint.h>

#define EAN_BTN_0 0
#define EAN_BTN_1 1

class EAN_BUTTON
{
public:
  EAN_BUTTON(void);

  int getButtonStatus(const uint8_t ean_button_id);
  void add_console_tests(void);

private:
};

extern EAN_BUTTON BUTTON;

#endif
