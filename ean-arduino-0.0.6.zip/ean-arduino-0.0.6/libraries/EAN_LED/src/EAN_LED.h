/*
 * 	EAN_LED.h
 *	Description: led module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef _EAN_LED_H_
#define _EAN_LED_H_
#include <stdint.h>
#define EAN_LED_R 0
#define EAN_LED_G 1
#define EAN_LED_B 2

class EAN_LED
{
public:
  EAN_LED(void);
  void leds_on(void);
  void leds_off(void);
  void led_on(const uint8_t ean_led_id);
  void led_off(const uint8_t ean_led_id);

  void add_console_tests(void);

private:
};

extern EAN_LED LED;

#endif
