/*
 * 	EAN_System_Time.h
 *	Description: System Time module
 *  Created on: 2 March 2023
 *  Author: Andrea Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_SYSTEM_TIME_H_
#define  _EAN_SYSTEM_TIME_H_

#include <stdint.h>

class EAN_System_Time
{
  public:

    EAN_System_Time(void);
    uint32_t get_time_epoch_format(void);
    struct tm get_time_struct_format(void);
    void set_time_epoch_format(uint32_t time_u32);
    void set_time_struct_format(struct tm time_tm);

    void add_console_tests(void);

  private:

};

extern EAN_System_Time System_Time;

#endif


